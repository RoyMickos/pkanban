dependencies = {
	layers: [
		{
			name: "../dojox/cometd.js",
			dependencies: [
				"dojox.cometd"
			]
		}
	],

	prefixes: [
		[ "dijit", "../dijit" ],
		[ "dojox", "../dojox" ]
	]
};
