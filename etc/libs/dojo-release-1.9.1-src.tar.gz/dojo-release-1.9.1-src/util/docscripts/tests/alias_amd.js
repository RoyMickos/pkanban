define(["dojo","dijit"], function(_dojo){

    dojo.sampleFunction = function(a, b, c){
        // summary: WTF
        return ""; // String
    }
    
});