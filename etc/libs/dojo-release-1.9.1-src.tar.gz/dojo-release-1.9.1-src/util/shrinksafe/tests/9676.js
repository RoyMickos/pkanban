// make sure plus and pos don't become inc.
var result = 1 + +2 - -3;

